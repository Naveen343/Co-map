function opennav(){
    document.getElementById("sidenav").style.width="250px";
    document.getElementById("header").style.filter = "brightness(93%)";
    document.getElementById("section").style.filter = "brightness(93%)";
    }
function closenav(){
    document.getElementById("sidenav").style.width="0%";
    document.getElementById("header").style.filter = "brightness(100%)";
    document.getElementById("section").style.filter = "brightness(100%)";
}